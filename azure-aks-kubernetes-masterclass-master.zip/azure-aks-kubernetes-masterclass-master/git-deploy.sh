#!/bin/sh

echo "Add files and do local commit"
git add .
git commit -am "Welcome to Stack Simplify"

echo "Pushing to Github Repository"
git push
