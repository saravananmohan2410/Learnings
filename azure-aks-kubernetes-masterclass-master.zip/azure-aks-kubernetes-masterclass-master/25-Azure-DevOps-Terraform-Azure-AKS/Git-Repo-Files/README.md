# Provision Azure AKS Cluster using Terraform and Azure DevOps

## For Step by Step Instructions
- [Step by Step Instructions](https://github.com/stacksimplify/azure-aks-kubernetes-masterclass/tree/master/25-Azure-DevOps-Terraform-Azure-AKS)