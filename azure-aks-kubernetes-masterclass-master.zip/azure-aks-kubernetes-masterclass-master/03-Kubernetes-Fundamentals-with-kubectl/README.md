# Kubernetes Fundaments using Imperative Approach using kubectl


| S.No  | Topic Name |
| ------| ------------- |
| 01.   | Pods   |
| 02.   | ReplicaSets  |
| 03.   | Deployments  |
| 04.   | Services  |