# Azure Container Registry Integrate wtih AKS

1. Attach Azure Container Registry to AKS
2. Use Service Principal to access ACR and Schedule workload on AKS Nodepools
3. Use Service Principal to access ACR and Schedule workload on AKS Virtual Nodes